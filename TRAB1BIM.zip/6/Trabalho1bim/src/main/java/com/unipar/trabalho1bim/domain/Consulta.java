package com.unipar.trabalho1bim.domain;

import com.unipar.trabalho1bim.dto.ConsultaCancelamentoDTO;
import com.unipar.trabalho1bim.dto.ConsultaInsertRequestDTO;
import com.unipar.trabalho1bim.services.MotivoCancelamento;

public class Consulta {
    private Integer id;
    private Integer medicoId;
    private Integer pacienteId;
    private String data;
    private String hora;
    private String ativo;
    private String motivo;


    public Consulta() {}

    public Consulta(ConsultaInsertRequestDTO consultaInsertRequestDTO) {
        this.medicoId = consultaInsertRequestDTO.getMedicoId();
        this.pacienteId = consultaInsertRequestDTO.getPacienteId();
        this.data = consultaInsertRequestDTO.getData();
        this.hora = consultaInsertRequestDTO.getHora();
    }

    public Consulta(ConsultaCancelamentoDTO consultaCancelamentoDTO) {
        this.id = consultaCancelamentoDTO.getId();
        this.motivo = consultaCancelamentoDTO.getMotivo();
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getAtivo() {
        return ativo;
    }

    public void setAtivo(String ativo) {
        this.ativo = ativo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMedicoId() {
        return medicoId;
    }

    public void setMedicoId(Integer medicoId) {
        this.medicoId = medicoId;
    }

    public Integer getPacienteId() {
        return pacienteId;
    }

    public void setPacienteId(Integer pacienteId) {
        this.pacienteId = pacienteId;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public void add(Consulta consulta) {
    }
}
