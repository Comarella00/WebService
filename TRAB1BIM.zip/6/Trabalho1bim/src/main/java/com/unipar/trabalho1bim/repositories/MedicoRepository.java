package com.unipar.trabalho1bim.repositories;

import com.unipar.trabalho1bim.domain.Medico;
import com.unipar.trabalho1bim.infraestructure.ConnectionFactory;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicoRepository {
    private static final String INSERT = "insert into MEDICOS (nome, email, telefone, crm, " +
            "especialidade, logradouro, numero, complemento, bairro) values (?, ?, ?, ?, ?, ?, ?, ? , ?) ";
    private static final String UPDATE = "update MEDICOS set nome = ?, telefone = ?, logradouro = ?, numero = ?, complemento = ?, bairro = ? where id = ?";
    private static final String FIND_ALL = "select id, nome, ativo from medicos";
    private static final String INATIVAR = "update MEDICOS set ativo = false where id = ?";

    public Medico inserir(Medico medico) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            conn = new ConnectionFactory().getConnection();

            pstmt = conn.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setString(1, medico.getNome());
            pstmt.setString(2, medico.getEmail());
            pstmt.setString(3, medico.getTelefone());
            pstmt.setString(4, medico.getCrm());
            pstmt.setString(5, medico.getEspecialidade());
            pstmt.setString(6, medico.getLogradouro());
            pstmt.setString(7, medico.getNumero());
            pstmt.setString(8, medico.getComplemento());
            pstmt.setString(9, medico.getBairro());
            pstmt.executeUpdate();

            rs = pstmt.getGeneratedKeys();

            rs.next();
            medico.setId(rs.getInt(1));
            medico.setAtivo(true);
        } finally{
            if (pstmt != null) pstmt.close();
            if (rs != null) rs.close();
            if (conn != null) conn.close();
        }
        return medico;
    }

    public Medico inativar(Medico medico) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(INATIVAR);
            pstmt.setInt(1, medico.getId());
            pstmt.executeUpdate();
        } finally {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
        return medico;
    }
    public Medico editar(Medico medico) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(UPDATE);
            pstmt.setString(1, medico.getNome());
            pstmt.setString(2, medico.getTelefone());
            pstmt.setString(3, medico.getLogradouro());
            pstmt.setString(4, medico.getNumero());
            pstmt.setString(5, medico.getComplemento());
            pstmt.setString(6, medico.getBairro());
            pstmt.setInt(7, medico.getId());

            pstmt.executeUpdate();
        } finally {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
        return medico;
    }

    public List<Medico> buscarTodos() throws SQLException, NamingException {
        List<Medico> medicos = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Medico medico = new Medico();
                medico.setId(rs.getInt("id"));
                medico.setNome(rs.getString("nome"));
                medico.setAtivo(rs.getBoolean("ativo"));
                medicos.add(medico);
            }
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return medicos;
}
}