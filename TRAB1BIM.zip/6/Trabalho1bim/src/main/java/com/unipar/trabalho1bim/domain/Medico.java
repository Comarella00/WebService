package com.unipar.trabalho1bim.domain;

import com.unipar.trabalho1bim.dto.MedicoCancelarRequestDTO;
import com.unipar.trabalho1bim.dto.MedicoInsertRequestDTO;
import com.unipar.trabalho1bim.dto.MedicoUpdateRequestDTO;

import java.util.List;

public class Medico {
    private Integer id;
    private String nome;
    private String email;
    private String telefone;
    private String crm;
    private String especialidade;
    private String logradouro;
    private String numero;
    private String bairro;
    private String complemento;
    private boolean ativo;

    public Medico() {}

    public Medico(MedicoInsertRequestDTO medicoInsertRequestDTO) {
        this.nome = medicoInsertRequestDTO.getNome();
        this.email = medicoInsertRequestDTO.getEmail();
        this.telefone = medicoInsertRequestDTO.getTelefone();
        this.crm = medicoInsertRequestDTO.getCrm();
        this.especialidade = medicoInsertRequestDTO.getEspecialidade();
        this.logradouro = medicoInsertRequestDTO.getLogradouro();
        this.numero = medicoInsertRequestDTO.getNumero();
        this.bairro = medicoInsertRequestDTO.getBairro();
        this.complemento = medicoInsertRequestDTO.getComplemento();
    }

    public Medico(MedicoUpdateRequestDTO medicoUpdateRequestDTO) {
        this.id = medicoUpdateRequestDTO.getId();
        this.nome = medicoUpdateRequestDTO.getNome();
        this.telefone = medicoUpdateRequestDTO.getTelefone();
        this.logradouro = medicoUpdateRequestDTO.getLogradouro();
        this.numero = medicoUpdateRequestDTO.getNumero();
        this.bairro = medicoUpdateRequestDTO.getBairro();
        this.complemento = medicoUpdateRequestDTO.getComplemento();
    }

    public Medico(MedicoCancelarRequestDTO medicoCancelarRequestDTO) {
        this.id = medicoCancelarRequestDTO.getId();
    }

    public Medico(Medico medico) {

    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public void inativar() {
        this.ativo = false;
    }
}
