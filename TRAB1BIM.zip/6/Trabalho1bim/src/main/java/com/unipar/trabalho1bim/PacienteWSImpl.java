package com.unipar.trabalho1bim;

import com.unipar.trabalho1bim.domain.Paciente;
import com.unipar.trabalho1bim.dto.PacienteCancelarRequestDTO;
import com.unipar.trabalho1bim.dto.PacienteInsertRequestDTO;
import com.unipar.trabalho1bim.dto.PacienteUpdateRequestDTO;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import com.unipar.trabalho1bim.interfaces.PacienteWS;
import com.unipar.trabalho1bim.services.PacienteService;
import jakarta.jws.WebService;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService
public class PacienteWSImpl implements PacienteWS {
    @Override
    public Paciente inserir(PacienteInsertRequestDTO pacienteInsertRequestDTO) throws BusinessException {
        Paciente paciente = new Paciente(pacienteInsertRequestDTO);
        PacienteService pacienteService = new PacienteService();
        return pacienteService.inserir(paciente);
    }

    @Override
    public Paciente editar(PacienteUpdateRequestDTO pacienteUpdateRequestDTO) throws BusinessException{
        Paciente paciente = new Paciente(pacienteUpdateRequestDTO);
        PacienteService pacienteService = new PacienteService();
        return pacienteService.editar(paciente);
    }

    @Override
    public Paciente inativar(PacienteCancelarRequestDTO pacienteCancelarRequestDTO) throws BusinessException{
        Paciente paciente = new Paciente(pacienteCancelarRequestDTO);
        PacienteService pacienteService = new PacienteService();
        return pacienteService.inativar(paciente);
    }

    @Override
    public List<Paciente> buscarTodos() throws BusinessException {
        PacienteService pacienteService = new PacienteService();
        return pacienteService.buscarTodos();
    }


}