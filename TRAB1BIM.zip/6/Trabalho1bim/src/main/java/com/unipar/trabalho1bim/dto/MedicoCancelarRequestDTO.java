package com.unipar.trabalho1bim.dto;

public class MedicoCancelarRequestDTO {
    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
