package com.unipar.trabalho1bim.services;

import com.unipar.trabalho1bim.domain.Paciente;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import com.unipar.trabalho1bim.repositories.MedicoRepository;
import com.unipar.trabalho1bim.repositories.PacienteRepository;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

public class PacienteService {

    private final PacienteRepository pacienteRepository;
    public PacienteService() {
        pacienteRepository = new PacienteRepository();
    }

    public Paciente inserir(Paciente paciente) throws BusinessException {
        if (paciente.getNome() == null || paciente.getNome().isEmpty()) {
            throw new BusinessException("Nome não pode ser nulo");
        }

        if (paciente.getCpf() == null || paciente.getCpf().isEmpty()) {
            throw new BusinessException("CPF não pode ser nulo");
        }

        try {
            return pacienteRepository.inserir(paciente);
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao inserir paciente: " + e.getMessage());
        }
    }

    public Paciente editar(Paciente paciente) throws BusinessException{
        if (paciente.getNome() == null || paciente.getNome().isEmpty()) {
            throw new BusinessException("Nome do Paciente é obrigatório");
        }

        if (paciente.getNome().length() > 100) {
            throw new BusinessException("Nome do Paciente deve ter no máximo 100 caracteres");
        }

        try {
            pacienteRepository.editar(paciente);
            return paciente;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao editar Paciente.");
        }
    }

    public List<Paciente> buscarTodos() throws BusinessException {
        try {
            return pacienteRepository.buscarTodos();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao buscar Pacientes: ");
        }
    }

    public Paciente inativar(Paciente paciente) {
        try {
            pacienteRepository.inativar(paciente);
            return paciente;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao inativar Paciente.");
        }
    }
}
