package com.unipar.trabalho1bim.services;

import com.unipar.trabalho1bim.domain.Consulta;
import com.unipar.trabalho1bim.domain.Medico;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import com.unipar.trabalho1bim.repositories.ConsultaRepository;
import com.unipar.trabalho1bim.repositories.MedicoRepository;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

public class ConsultaService {

    private ConsultaRepository consultaRepository = new ConsultaRepository();

    public ConsultaService() {
        consultaRepository = new ConsultaRepository();
    }

    public Consulta inserir(Consulta consulta) throws BusinessException {
        if (consulta.getPacienteId() == null) {
            throw new BusinessException("Id do paciente não pode ser nulo");
        }
        try {
            return consultaRepository.inserir(consulta);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao inserir paciente a consulta.");
        }
    }

    public Consulta cancelamento(Consulta consulta) throws BusinessException {


        try {
            consultaRepository.cancelamento(consulta);
            return consulta;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao cancelar consulta.");
        }
    }

    public List<Consulta> buscarTodos() throws BusinessException {
        try {
            return consultaRepository.buscarTodos();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao buscar Consultas.");
        }
    }
}
