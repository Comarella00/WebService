package com.unipar.trabalho1bim.dto;

public class ConsultaInsertRequestDTO {

        private Integer pacienteId;
        private Integer medicoId;
        private String data;
        private String hora;

        public Integer getPacienteId() {
                return pacienteId;
        }

        public void setPacienteId(Integer pacienteId) {
                this.pacienteId = pacienteId;
        }

        public Integer getMedicoId() {
                return medicoId;
        }

        public void setMedicoId(Integer medicoId) {
                this.medicoId = medicoId;
        }

        public String getData() {
                return data;
        }

        public void setData(String data) {
                this.data = data;
        }

        public String getHora() {
                return hora;
        }

        public void setHora(String hora) {
                this.hora = hora;
        }
}
