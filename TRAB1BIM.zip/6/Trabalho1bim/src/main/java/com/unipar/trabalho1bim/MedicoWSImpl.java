package com.unipar.trabalho1bim;

import com.unipar.trabalho1bim.domain.Medico;
import com.unipar.trabalho1bim.dto.MedicoCancelarRequestDTO;
import com.unipar.trabalho1bim.dto.MedicoInsertRequestDTO;
import com.unipar.trabalho1bim.dto.MedicoUpdateRequestDTO;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import com.unipar.trabalho1bim.interfaces.MedicoWS;
import com.unipar.trabalho1bim.services.MedicoService;
import jakarta.jws.WebService;

import java.util.List;

@WebService
public class MedicoWSImpl implements MedicoWS {
    @Override
    public Medico inserir(MedicoInsertRequestDTO medicoInsertRequestDTO) throws BusinessException {
        Medico medico = new Medico(medicoInsertRequestDTO);

        MedicoService medicoService = new MedicoService();
        return medicoService.inserir(medico);
    }

    @Override
    public Medico editar(MedicoUpdateRequestDTO medicoUpdateRequestDTO) throws BusinessException {
        Medico medico = new Medico(medicoUpdateRequestDTO);
        MedicoService medicoService = new MedicoService();
        return medicoService.editar(medico);
    }

    @Override
    public List<Medico> buscarTodos() throws BusinessException {
        MedicoService medicoService = new MedicoService();
        return medicoService.buscarTodos();
    }


    @Override
    public Medico inativar(MedicoCancelarRequestDTO medicoCancelarRequestDTO) throws BusinessException {
        Medico medicos = new Medico(medicoCancelarRequestDTO);
        MedicoService medicoService = new MedicoService();
        return medicoService.inativar(medicos);
    }
}
