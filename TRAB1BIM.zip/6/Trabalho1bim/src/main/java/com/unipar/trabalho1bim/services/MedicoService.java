package com.unipar.trabalho1bim.services;

import com.unipar.trabalho1bim.domain.Medico;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import com.unipar.trabalho1bim.repositories.MedicoRepository;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

public class MedicoService {

    private MedicoRepository medicoRepository = new MedicoRepository();
    public MedicoService() {
        medicoRepository = new MedicoRepository();
    }


    public Medico inserir (Medico medico) throws BusinessException {
        if(medico.getNome() == null || medico.getNome().isEmpty()) {
            throw new BusinessException("Nome não pode ser Nulo");
        }
        try {
            return medicoRepository.inserir(medico);
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao inserir medico.");
        }
    }

    public Medico editar(Medico medico) throws BusinessException {
        if (medico.getNome() == null || medico.getNome().isEmpty()) {
            throw new BusinessException("Nome do Médico é obrigatório");
        }

        if (medico.getNome().length() > 100) {
            throw new BusinessException("Nome do Médico deve ter no máximo 100 caracteres");
        }

        try {
            medicoRepository.editar(medico);
            return medico;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao editar Médico.");
        }
    }

    public Medico inativar(Medico medico) throws BusinessException {
        try {
            medicoRepository.inativar(medico);
            return medico;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao inativar Médico.");
        }
      }

    public List<Medico> buscarTodos() throws BusinessException {
        try {
            return medicoRepository.buscarTodos();
        } catch (SQLException | NamingException e) {
            e.printStackTrace();
            throw new BusinessException("Erro ao buscar Medicos.");
 }
}

}