package com.unipar.trabalho1bim;

import com.unipar.trabalho1bim.domain.Consulta;
import com.unipar.trabalho1bim.domain.Medico;
import com.unipar.trabalho1bim.dto.ConsultaCancelamentoDTO;
import com.unipar.trabalho1bim.dto.ConsultaInsertRequestDTO;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import com.unipar.trabalho1bim.services.ConsultaService;
import com.unipar.trabalho1bim.services.MedicoService;
import jakarta.jws.WebService;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService
public class ConsultaWSImpl {

    public Consulta inserir(ConsultaInsertRequestDTO consultaInsertRequestDTO) throws BusinessException, SQLException, NamingException {
        Consulta consulta = new Consulta(consultaInsertRequestDTO);
        ConsultaService consultaService = new ConsultaService();
        return consultaService.inserir(consulta);
    }

    public Consulta cancelamento(ConsultaCancelamentoDTO consultaCancelamentoDTO) throws BusinessException, SQLException, NamingException {
        Consulta consulta = new Consulta(consultaCancelamentoDTO);
        ConsultaService consultaService = new ConsultaService();
        return consultaService.cancelamento(consulta);
    }


    public List<Consulta> buscarTodos() throws BusinessException {
        ConsultaService consultaService = new ConsultaService();
        return consultaService.buscarTodos();
    }
}