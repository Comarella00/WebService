package com.unipar.trabalho1bim.interfaces;

import com.unipar.trabalho1bim.domain.Consulta;

import com.unipar.trabalho1bim.domain.Medico;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import com.unipar.trabalho1bim.dto.ConsultaCancelamentoDTO;
import com.unipar.trabalho1bim.dto.ConsultaInsertRequestDTO;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService
public interface ConsultaWS {
    @WebMethod
    Consulta inserir(ConsultaInsertRequestDTO consulta) throws BusinessException, SQLException, NamingException;

    @WebMethod
    Consulta cancelamento(ConsultaCancelamentoDTO consulta) throws BusinessException;

    @WebMethod
    List<Consulta> buscarTodos() throws BusinessException;
}
