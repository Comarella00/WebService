package com.unipar.trabalho1bim.repositories;

import com.unipar.trabalho1bim.domain.Consulta;
import com.unipar.trabalho1bim.domain.Medico;
import com.unipar.trabalho1bim.infraestructure.ConnectionFactory;

import javax.naming.NamingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConsultaRepository {

    private static final String INSERT = "insert into CONSULTAS (pacientes_id, medicos_id, data, hora) values (?, ?, ?, ?) ";
    private static final String FIND_ALL = "select id, pacientes_id,medicos_id, data, hora from consultas";
    private static final String CANCELAMENTO = "update CONSULTAS set ativa = false, motivoCanc = ? where id = ?";

    public Consulta inserir(Consulta consulta) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            conn = new ConnectionFactory().getConnection();

            pstmt = conn.prepareStatement(INSERT, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, consulta.getPacienteId());
            pstmt.setInt(2, consulta.getMedicoId());
            pstmt.setString(3, consulta.getData());
            pstmt.setString(4, consulta.getHora());
            pstmt.executeUpdate();

            rs = pstmt.getGeneratedKeys();

            rs.next();
            consulta.setId(rs.getInt(1));
           //consulta.setAtivo(true);
        } finally{
            if (pstmt != null) pstmt.close();
            if (rs != null) rs.close();
            if (conn != null) conn.close();
        }
        return consulta;
    }


    public List<Consulta> buscarTodos() throws SQLException, NamingException {
        List<Consulta> consultas = new ArrayList<>();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(FIND_ALL);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                Consulta consulta = new Consulta();
                consulta.setId(rs.getInt("id"));
                consulta.setPacienteId(rs.getInt("pacientes_id"));
                consulta.setMedicoId(rs.getInt("medicos_id"));
                consulta.setData(rs.getString("data"));
                consulta.setHora(rs.getString("hora"));
                consultas.add(consulta);
            }
        } finally {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }

        return consultas;
    }

    public Consulta cancelamento(Consulta consulta) throws SQLException, NamingException {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = new ConnectionFactory().getConnection();
            pstmt = conn.prepareStatement(CANCELAMENTO);
            pstmt.setString(1, consulta.getMotivo());
            pstmt.setInt(2, consulta.getId());
            pstmt.executeUpdate();
        } finally {
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        }
        return consulta;
    }



}
