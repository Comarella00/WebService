package com.unipar.trabalho1bim.interfaces;

import com.unipar.trabalho1bim.domain.Paciente;
import com.unipar.trabalho1bim.dto.PacienteCancelarRequestDTO;
import com.unipar.trabalho1bim.dto.PacienteInsertRequestDTO;
import com.unipar.trabalho1bim.dto.PacienteUpdateRequestDTO;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import jakarta.jws.WebMethod;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

public interface PacienteWS {
    @WebMethod
    Paciente inserir(PacienteInsertRequestDTO paciente);
    Paciente editar(PacienteUpdateRequestDTO paciente);
    Paciente inativar(PacienteCancelarRequestDTO paciente);

    @WebMethod
    List<Paciente> buscarTodos() throws BusinessException;

}