package com.unipar.trabalho1bim.dto;

import com.unipar.trabalho1bim.services.MotivoCancelamento;

public class ConsultaCancelamentoDTO {

    private Integer id;
    private String motivo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
}



