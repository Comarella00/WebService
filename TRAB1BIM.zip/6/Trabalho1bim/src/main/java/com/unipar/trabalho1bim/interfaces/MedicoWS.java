package com.unipar.trabalho1bim.interfaces;

import com.unipar.trabalho1bim.domain.Medico;
import com.unipar.trabalho1bim.dto.MedicoCancelarRequestDTO;
import com.unipar.trabalho1bim.dto.MedicoInsertRequestDTO;
import com.unipar.trabalho1bim.dto.MedicoUpdateRequestDTO;
import com.unipar.trabalho1bim.exceptions.BusinessException;
import jakarta.jws.WebMethod;

import java.util.List;

public interface MedicoWS {
    @WebMethod
    Medico inserir(MedicoInsertRequestDTO medico);

    @WebMethod
    Medico editar(MedicoUpdateRequestDTO medico);

    @WebMethod
    List<Medico> buscarTodos() throws BusinessException;

    @WebMethod
    Medico inativar(MedicoCancelarRequestDTO medico);
}
