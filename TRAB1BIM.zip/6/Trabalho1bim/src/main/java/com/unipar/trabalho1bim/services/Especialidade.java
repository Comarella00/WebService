package com.unipar.trabalho1bim.services;

public enum Especialidade {
    Ortopedia,
    Cardiologia,
    Ginecologia,
    Dermatologia
}
